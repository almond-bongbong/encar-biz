export { default } from './MyPage';
