import React from 'react';

const MyPage: React.FC = () => {
  return <div>마이페이지 입니다.</div>;
};

export default MyPage;
