export { default } from './SidePanel';
