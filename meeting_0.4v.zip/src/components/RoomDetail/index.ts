export { default } from './RoomDetail';
