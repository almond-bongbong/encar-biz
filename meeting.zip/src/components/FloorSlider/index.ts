export { default } from './FloorSlider';
