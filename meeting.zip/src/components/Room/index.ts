export { default } from './Room';
