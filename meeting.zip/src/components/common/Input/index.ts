export { default } from './Input';
