# Encar meeting reservation service

- Super easy
- Super fast

## Todo

- [ ] 이벤트 발생시 interval 정지 기능 구현 